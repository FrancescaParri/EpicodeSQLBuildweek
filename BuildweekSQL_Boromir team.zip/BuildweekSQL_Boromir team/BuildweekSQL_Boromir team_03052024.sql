create database VendiCoseSPA;
-- drop database VendicoseSPA;
-- SET SQL_SAFE_UPDATES = 0;

use VendiCoseSPA;

-- Tabella MAGAZZINO
CREATE TABLE Magazzino (
    IdMagazzino INT PRIMARY KEY,
    NomeMagazzino VARCHAR(50),
    QtaProdotto INT
);

-- Tabella NEGOZIO
CREATE TABLE Negozio (
    IdNegozio INT PRIMARY KEY,
    NomeNegozio VARCHAR(50),
    IdMagazzino INT,
    foreign key (IdMagazzino)
    references Magazzino(IdMagazzino)
);


-- Tabella CATEGORIA
CREATE TABLE Categoria (
    IdCategoria INT PRIMARY KEY,
    NomeCategoria VARCHAR(50)
);

-- Tabella SOGLIA_MINIMA_CATEGORIA
CREATE TABLE SogliaMinimaCategoria (
    IdMagazzino INT ,
    IdCategoria INT ,
    SogliaSicurezza INT,
    PRIMARY KEY (IdCategoria , IdMagazzino),
    FOREIGN KEY (IdMagazzino)
        REFERENCES Magazzino (IdMagazzino),
    FOREIGN KEY (IdCategoria)
        REFERENCES Categoria (IdCategoria)
);

-- Tabella PRODOTTO
CREATE TABLE Prodotto (
    IDProdotto int PRIMARY KEY,
    NomeProdotto VarChar(50),
    PrezzoUnitario Decimal(5,2),
    -- Peso Decimal(5,2),
    IdCategoria int,
    FOREIGN KEY (IdCategoria)
    REFERENCES Categoria(IdCategoria)
);



-- Tabella VENDITA
CREATE TABLE Vendita (
    IdVendita INT PRIMARY KEY,
    DataVendita DATE,
    IDNegozio INT,
    FOREIGN KEY (IdNegozio)
        REFERENCES Negozio (IdNegozio)
);


-- Tabella TRANSAZIONE
CREATE TABLE Transazione (
    IdTransazione INT,
    IdVendita INT,
    IdProdotto INT,
    QuantitaProd INT,
    PRIMARY KEY (IdVendita , IdTransazione),
    FOREIGN KEY (IdVendita)
    REFERENCES Vendita (IdVendita),
    FOREIGN KEY (IdProdotto)
    REFERENCES Prodotto (IdProdotto)
);


CREATE TABLE Giacenza (
    IDProd INT,
    IdMag INT,
    QtaProd INT,
    PRIMARY KEY (IDProd, IdMag),
    FOREIGN KEY (IDProd) REFERENCES Prodotto(IDProdotto),
    FOREIGN KEY (IdMag) REFERENCES Magazzino(IdMagazzino)
);

-- Popolamento tabella Categoria
INSERT INTO Categoria (IdCategoria, NomeCategoria) VALUES
(1, 'Alimentari'),
(2, 'Elettronica'),
(3, 'Abbigliamento'),
(4, 'Cosmetici'),
(5, 'Giocattoli');

-- Popolamento tabella Magazzino
INSERT INTO Magazzino (IdMagazzino, NomeMagazzino, QtaProdotto) VALUES
(1, 'Magazzino Centrale', 1000),
(2, 'Magazzino Nord', 800),
(3, 'Magazzino Sud', 1200);

-- Popolamento tabella Negozio
INSERT INTO Negozio (IdNegozio, NomeNegozio, IdMagazzino) VALUES
(1, 'Supermercato Uno', 1),
(2, 'Elettronica Top', 2),
(3, 'Boutique Chic', 3);

select * from
negozio;

-- Popolamento tabella Prodotto
INSERT INTO Prodotto (IDProdotto, NomeProdotto, PrezzoUnitario, IdCategoria) VALUES
(1, 'Pasta', 1.5, 1),
(2, 'Smartphone', 500, 2),
(3, 'Maglione', 30, 3),
(4, 'Rossetto', 15, 4),
(5, 'Lego', 20, 5);



-- Popolamento tabella Vendita
INSERT INTO Vendita (IdVendita, DataVendita, IDNegozio) VALUES
(1, '2024-04-01', 1),
(2, '2024-04-02', 2),
(3, '2024-04-03', 3);

-- Popolamento tabella Transazione
INSERT INTO Transazione (IdTransazione, IdVendita, IdProdotto, QuantitaProd) VALUES
(1, 1, 1, 10),
(2, 2, 2, 5),
(3, 3, 3, 8);

-- Popolamento tabella SogliaMinimaCategoria
INSERT INTO SogliaMinimaCategoria (IdMagazzino, IdCategoria, SogliaSicurezza) VALUES
(1, 1, 200),
(1, 2, 100),
(2, 3, 150),
(3, 4, 80),
(3, 5, 120);

insert into SogliaMinimaCategoria (IdMagazzino, IdCategoria, SogliaSicurezza) VALUES
(1, 3, 50),
(1, 4, 70),
(1, 5, 100),
(2, 1, 20),
(2, 2, 30),
(2, 4, 120),
(2, 5, 220),
(3, 1, 50),
(3, 2, 30),
(3, 3, 10);

-- Popolamento tabella Giacenza
INSERT INTO Giacenza (IDProd, IdMag, QtaProd) VALUES
(1, 1, 500),
(2, 2, 300),
(3, 3, 200),
(4, 1, 100),
(5, 3, 150);

INSERT INTO Giacenza (IDProd, IdMag, QtaProd) VALUES
(2, 1, 50),
(3, 1, 70),
(5, 1, 100),
(1, 2, 150),
(3, 2, 70),
(4, 2, 150),
(5, 2, 80),
(1, 3, 150),
(2, 3, 20),
(4, 3, 100);

/* 
Creazione di una vista per verifica della giacenza di prodotto per categoria e magazzino e confronto
con la SogliaSicurezza per quella categoria di prodotto
*/
create view Controllo
as
SELECT P.NomeProdotto, p.idprodotto,c.nomecategoria,M.NomeMagazzino, g.QtaProd, S.SogliaSicurezza
FROM Magazzino AS M
JOIN SogliaMinimaCategoria AS S ON M.IdMagazzino = S.IdMagazzino
JOIN Prodotto AS P ON S.IdCategoria = P.IdCategoria
join Categoria as C on s.IdCategoria=C.idcategoria
join giacenza as G on g.IdMag=m.idmagazzino and g.IDProd=p.idprodotto
order by 2;

SELECT 
    *
FROM
    controllo;


-- Inseriamo una vendita con 2 transazioni recenti
Insert into vendita (idVendita,Datavendita,IdNegozio)
Values (4, '2024-05-03', 1);

INSERT INTO Transazione (IdTransazione, IdVendita, IdProdotto, QuantitaProd) VALUES
(1,4,3,50),
(2,4,5,15);


-- Aggiornamento giacenza magazzino a seguito di una vendita
Start transaction;
 
UPDATE Giacenza AS G
        JOIN
    magazzino AS m ON g.idmag = m.idmagazzino
        JOIN
    Negozio AS N ON M.IdMagazzino = N.IdMagazzino
        JOIN
    Vendita AS V ON N.IdNegozio = V.IdNegozio
        JOIN
    Transazione AS T ON V.IdVendita = T.IdVendita
        JOIN
    prodotto AS P ON p.idprodotto = t.idprodotto
        AND g.idprod = p.idprodotto 
SET 
    g.QtaProd = g.QtaProd - T.QuantitaProd
WHERE
    V.IdVendita = 4;

Rollback; 
    
    SELECT 
    *
FROM
    controllo;
    
-- Creazione vista per aggiornamento della quantità di restock 

create view Controllo2 as 
select 	p.IDProdotto,
		p.NomeProdotto,
		s.IdCategoria,
        c.NomeCategoria,
        s.sogliasicurezza,
        s.idmagazzino
from 		sogliaminimacategoria AS s
                INNER JOIN
            categoria AS c ON s.IdCategoria = c.IdCategoria
                INNER JOIN
            prodotto AS p ON c.IdCategoria = p.IdCategoria;
            
   -- drop view controllo2;   
            
-- Aggiornamento giacenza per effettuare il restock
UPDATE giacenza AS Restock 
SET 
    Restock.qtaprod = Restock.qtaprod + (
							SELECT 
								c2.sogliasicurezza
							FROM
								Controllo2 AS c2
							WHERE
								Restock.idprod = c2.IDProdotto
									AND restock.idmag = c2.IdMagazzino
                                    )
WHERE
    Restock.idprod = (
		SELECT  c2.IDProdotto
		FROM	Controllo2 AS c2
        WHERE	Restock.idprod = c2.IDProdotto
		AND 	restock.idmag = c2.IdMagazzino)
        AND 	restock.qtaprod < (
									SELECT c2.sogliasicurezza
									FROM  Controllo2 AS c2
									WHERE Restock.idprod = c2.IDProdotto
									AND   restock.idmag = c2.IdMagazzino
									);